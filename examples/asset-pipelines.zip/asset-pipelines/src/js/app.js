console.log(greeting + " assets");
